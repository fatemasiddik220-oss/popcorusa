/**
 * POP TELEGRAM MINI APP - DYNAMIC ADS PROVIDER SERVICE
 * Supports: Adsgram, Monetag, GoogleAdSense
 * Dynamic script injection, provider switching, and 10s interstitial lifecycle.
 */

declare global {
  interface Window {
    Adsgram?: {
      init: (params: { blockId: string; debug?: boolean }) => {
        show: () => Promise<{ done: boolean; description?: string; state?: string }>;
      };
    };
    monetag?: any;
    show_native_ad?: any;
  }
}

export type AdProviderType = 'adsgram' | 'monetag' | 'googleadsense' | string;

export interface AdShowResult {
  success: boolean;
  provider: string;
  blockId: string;
  watchedDurationSeconds: number;
  rewardEarned: boolean;
  error?: string;
}

class AdsProviderService {
  private currentProvider: AdProviderType = 'adsgram';
  private currentSecret: string = 'test_block_12345';
  private adsgramController: any = null;
  private scriptLoaded: boolean = false;

  /**
   * Configure dynamic provider and block ID in real-time from server / admin config
   */
  public configure(provider: AdProviderType, secret: string) {
    const normalizedProvider = (provider || 'adsgram').toLowerCase();
    const isNew = normalizedProvider !== this.currentProvider || secret !== this.currentSecret;

    this.currentProvider = normalizedProvider;
    this.currentSecret = secret || 'test_block_12345';

    if (isNew) {
      this.loadProviderScript();
    }
  }

  public getProvider(): AdProviderType {
    return this.currentProvider;
  }

  public getSecret(): string {
    return this.currentSecret;
  }

  /**
   * Load official provider SDK script dynamically into the DOM
   */
  public loadProviderScript(): void {
    if (typeof window === 'undefined') return;

    try {
      if (this.currentProvider === 'adsgram') {
        const existingScript = document.getElementById('adsgram-sdk-script');
        if (!existingScript) {
          const script = document.createElement('script');
          script.id = 'adsgram-sdk-script';
          script.src = 'https://sad.adsgram.ai/js/sad.min.js';
          script.async = true;
          script.onload = () => {
            this.scriptLoaded = true;
            this.initAdsgram();
          };
          document.head.appendChild(script);
        } else if (window.Adsgram) {
          this.initAdsgram();
        }
      } else if (this.currentProvider === 'monetag') {
        // Monetag script injection
        const existingScript = document.getElementById('monetag-sdk-script');
        if (!existingScript && this.currentSecret) {
          const script = document.createElement('script');
          script.id = 'monetag-sdk-script';
          script.src = `https://alwingulla.com/88/tag.min.js?zone=${this.currentSecret}`;
          script.async = true;
          script.setAttribute('data-zone', this.currentSecret);
          document.head.appendChild(script);
        }
      }
    } catch (err) {
      console.warn('[AdsProvider] Failed to load provider script:', err);
    }
  }

  private initAdsgram(): void {
    if (typeof window !== 'undefined' && window.Adsgram) {
      try {
        this.adsgramController = window.Adsgram.init({
          blockId: this.currentSecret,
          debug: false
        });
        console.log(`[AdsProvider] Adsgram initialized with Block ID: ${this.currentSecret}`);
      } catch (err) {
        console.warn('[AdsProvider] Adsgram init failed:', err);
      }
    }
  }

  /**
   * Show native ad if SDK is available, or return fallback trigger
   */
  public async showNativeAd(): Promise<boolean> {
    if (this.currentProvider === 'adsgram' && this.adsgramController) {
      try {
        const res = await this.adsgramController.show();
        return res?.done === true;
      } catch (err) {
        console.warn('[AdsProvider] Native Adsgram show rejected:', err);
        return false;
      }
    }
    return false;
  }
}

export const adsProvider = new AdsProviderService();
