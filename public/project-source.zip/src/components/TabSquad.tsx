import React, { useState } from 'react';
import {
  Users2,
  Crown,
  Copy,
  Share2,
  CheckCircle2,
  AlertTriangle,
  Sparkles,
  ShieldCheck,
  ShieldAlert,
  ArrowRight,
  ExternalLink,
  Award,
  Clock,
  Smartphone,
  RefreshCw,
  Send,
  Play
} from 'lucide-react';
import confetti from 'canvas-confetti';
import { User, AdminConfig, ReferralUserItem, WeeklyPodiumUser, SquadCounts } from '../types.js';
import { haptic } from '../services/haptic.js';

interface TabSquadProps {
  user: User;
  config: AdminConfig;
  referrals: ReferralUserItem[];
  weeklyLeaderboard: WeeklyPodiumUser[];
  counts?: SquadCounts;
  onRefreshSquad?: () => Promise<void>;
  onClaimSquadCommission: () => Promise<void>;
  onOpenWalletModal: () => void;
}

export const TabSquad: React.FC<TabSquadProps> = ({
  user,
  config,
  referrals,
  weeklyLeaderboard,
  counts,
  onRefreshSquad,
  onClaimSquadCommission,
  onOpenWalletModal,
}) => {
  const [listToggle, setListToggle] = useState<'top' | 'my'>('my');
  const [referralFilter, setReferralFilter] = useState<'ALL' | 'QUALIFIED' | 'PENDING' | 'SAME_IP'>('ALL');
  const [isClaiming, setIsClaiming] = useState(false);
  const [isRefreshing, setIsRefreshing] = useState(false);
  const [copiedLink, setCopiedLink] = useState(false);
  const [claimSuccess, setClaimSuccess] = useState<string | null>(null);

  const referralLink = `https://t.me/PopCornUSA_BOT/app?startapp=ref_${user.telegramId}`;

  // Squad Breakdown Counters (Derived from API counts or calculated directly from referrals array)
  const totalJoined = counts?.total ?? referrals.length;
  
  const sameIpCount = counts?.same_ip ?? referrals.filter(r => 
    r.status === 'Unqualified (Same IP / Device Match)' ||
    r.status === 'UNQUALIFIED - SAME IP' || 
    r.status === 'UNQUALIFIED - SAME DEVICE' || 
    r.status === 'Unqualified' ||
    (r.hasWallet && r.hasChannel && r.isMultiAccount)
  ).length;

  const qualifiedCount = counts?.qualified ?? referrals.filter(r => 
    (r.status === 'Qualified' || r.status === 'QUALIFIED' || r.isQualified) && 
    !r.isMultiAccount && 
    r.status !== 'Unqualified (Same IP / Device Match)' &&
    r.status !== 'UNQUALIFIED - SAME IP' &&
    r.status !== 'UNQUALIFIED - SAME DEVICE'
  ).length;

  const pendingCount = counts?.pending ?? Math.max(0, totalJoined - qualifiedCount - sameIpCount);

  const handleCopyLink = () => {
    navigator.clipboard.writeText(referralLink);
    setCopiedLink(true);
    haptic.success();
    setTimeout(() => setCopiedLink(false), 2500);
  };

  const handleShareTelegram = () => {
    haptic.impact('medium');
    const shareText = "🍿 Join PopCornUSA BOT & Start Mining POP Coins Now! Get instant welcome bonus! 🚀";
    const tgShareUrl = `https://t.me/share/url?url=${encodeURIComponent(referralLink)}&text=${encodeURIComponent(shareText)}`;

    // Use Telegram WebApp native share dialog if running inside Telegram WebApp
    if (window.Telegram?.WebApp?.openTelegramLink) {
      window.Telegram.WebApp.openTelegramLink(tgShareUrl);
    } else {
      window.open(tgShareUrl, '_blank');
    }
  };

  const handleRefresh = async () => {
    if (isRefreshing || !onRefreshSquad) return;
    try {
      setIsRefreshing(true);
      haptic.selection();
      await onRefreshSquad();
    } catch (e) {
      console.warn('Failed to refresh squad:', e);
    } finally {
      setIsRefreshing(false);
    }
  };

  const handleClaimCommission = async () => {
    if (!user.tonWalletAddress) {
      haptic.warning();
      onOpenWalletModal();
      return;
    }

    if (user.unclaimedSquadPOP <= 0) {
      haptic.warning();
      return;
    }

    try {
      setIsClaiming(true);
      haptic.impact('heavy');
      await onClaimSquadCommission();
      haptic.success();

      confetti({
        particleCount: 50,
        spread: 60,
        origin: { y: 0.6 },
        colors: ['#00E5FF', '#FFE600'],
      });

      setClaimSuccess(`Claimed +${user.unclaimedSquadPOP.toFixed(2)} POP Squad Commission!`);
      setTimeout(() => setClaimSuccess(null), 3000);
    } catch (err: any) {
      haptic.error();
    } finally {
      setIsClaiming(false);
    }
  };

  // Top 3 Podium Sort (Podium order: 2nd on Left, 1st in Center, 3rd on Right)
  const rank1 = weeklyLeaderboard.find(u => u.rank === 1);
  const rank2 = weeklyLeaderboard.find(u => u.rank === 2);
  const rank3 = weeklyLeaderboard.find(u => u.rank === 3);
  const ranksRest = weeklyLeaderboard.filter(u => u.rank > 3);

  const qualifiedReferralsCount = referrals.filter(r => r.isQualified && !r.isMultiAccount).length;

  return (
    <div className="space-y-4 pb-20 pt-2 px-4 max-w-md mx-auto">
      
      {/* 1. USER INFO HEADER */}
      <div className="p-4 rounded-3xl bg-[#121824] border border-[#252D3D] flex items-center justify-between shadow-xl">
        <div className="flex items-center gap-3">
          {/* Avatar Placeholder */}
          <div className="w-12 h-12 rounded-2xl bg-gradient-to-tr from-[#00E5FF] to-[#FFE600] p-0.5 shadow-md">
            <div className="w-full h-full rounded-2xl bg-[#0B0E14] flex items-center justify-center font-display font-black text-white text-base uppercase">
              {user.username ? user.username.slice(0, 2) : 'PO'}
            </div>
          </div>

          <div>
            <div className="flex items-center gap-1.5">
              <h3 className="text-sm font-extrabold text-white">{user.firstName} {user.lastName}</h3>
              {user.isFlagged ? (
                <span className="text-[9px] bg-red-500/20 text-red-400 border border-red-500/40 px-1.5 py-0.5 rounded font-black flex items-center gap-0.5">
                  <ShieldAlert className="w-2.5 h-2.5" /> FLAGGED
                </span>
              ) : (
                <span className="text-[9px] bg-emerald-500/20 text-emerald-400 border border-emerald-500/30 px-1.5 py-0.5 rounded font-semibold flex items-center gap-0.5">
                  <ShieldCheck className="w-2.5 h-2.5" /> VERIFIED
                </span>
              )}
            </div>
            <span className="text-xs text-gray-400">@{user.username || 'unknown'}</span>
          </div>
        </div>

        <div className="text-right flex items-center gap-2">
          {onRefreshSquad && (
            <button
              onClick={handleRefresh}
              disabled={isRefreshing}
              title="Refresh Squad Data"
              className="p-2 rounded-xl bg-[#1A2234] border border-[#252D3D] text-gray-300 hover:text-white hover:border-[#00E5FF]/40 transition-all active:scale-95"
            >
              <RefreshCw className={`w-3.5 h-3.5 ${isRefreshing ? 'animate-spin text-[#00E5FF]' : ''}`} />
            </button>
          )}
          <div>
            <span className="text-[10px] text-gray-400 block font-semibold">Active Inviter</span>
            <span className="text-xs font-black text-[#FFE600] font-mono-digits">
              {qualifiedCount} Qualified
            </span>
          </div>
        </div>
      </div>

      {/* 2. SQUAD BREAKDOWN COUNTERS (4 DYNAMIC CARDS) */}
      <div className="space-y-1.5">
        <div className="flex items-center justify-between px-1">
          <div className="flex items-center gap-1.5">
            <Users2 className="w-3.5 h-3.5 text-[#00E5FF]" />
            <span className="text-xs font-extrabold text-white uppercase tracking-wider font-display">
              Squad Breakdown
            </span>
          </div>
          <span className="text-[10px] text-gray-400 font-mono-digits">
            Instant registration & live sync
          </span>
        </div>

        <div className="grid grid-cols-2 gap-2.5">
          {/* Card 1: Total Joined */}
          <div
            onClick={() => {
              setListToggle('my');
              setReferralFilter('ALL');
              haptic.selection();
            }}
            className={`p-3.5 rounded-2xl bg-[#121824] border transition-all cursor-pointer hover:border-[#00E5FF]/50 shadow-md ${
              listToggle === 'my' && referralFilter === 'ALL'
                ? 'border-[#00E5FF] ring-1 ring-[#00E5FF]/30 bg-[#121824]/90'
                : 'border-[#252D3D]'
            }`}
          >
            <div className="flex items-center justify-between mb-1">
              <span className="text-[11px] font-bold text-gray-400">Total Joined</span>
              <div className="w-6 h-6 rounded-lg bg-[#00E5FF]/15 flex items-center justify-center text-[#00E5FF]">
                <Users2 className="w-3.5 h-3.5" />
              </div>
            </div>
            <div className="text-2xl font-black text-white font-mono-digits">
              {totalJoined}
            </div>
            <span className="text-[10px] text-gray-400 block mt-0.5">
              All registered referees
            </span>
          </div>

          {/* Card 2: Pending Action */}
          <div
            onClick={() => {
              setListToggle('my');
              setReferralFilter('PENDING');
              haptic.selection();
            }}
            className={`p-3.5 rounded-2xl bg-[#121824] border transition-all cursor-pointer hover:border-amber-400/50 shadow-md ${
              listToggle === 'my' && referralFilter === 'PENDING'
                ? 'border-amber-400 ring-1 ring-amber-400/30 bg-amber-950/10'
                : 'border-[#252D3D]'
            }`}
          >
            <div className="flex items-center justify-between mb-1">
              <span className="text-[11px] font-bold text-gray-400">Pending Action</span>
              <div className="w-6 h-6 rounded-lg bg-amber-400/15 flex items-center justify-center text-amber-400">
                <Clock className="w-3.5 h-3.5" />
              </div>
            </div>
            <div className="text-2xl font-black text-amber-300 font-mono-digits">
              {pendingCount}
            </div>
            <span className="text-[10px] text-amber-400/80 block mt-0.5">
              Missing Wallet / Channel
            </span>
          </div>

          {/* Card 3: Qualified */}
          <div
            onClick={() => {
              setListToggle('my');
              setReferralFilter('QUALIFIED');
              haptic.selection();
            }}
            className={`p-3.5 rounded-2xl bg-[#121824] border transition-all cursor-pointer hover:border-emerald-400/50 shadow-md ${
              listToggle === 'my' && referralFilter === 'QUALIFIED'
                ? 'border-emerald-400 ring-1 ring-emerald-400/30 bg-emerald-950/10'
                : 'border-[#252D3D]'
            }`}
          >
            <div className="flex items-center justify-between mb-1">
              <span className="text-[11px] font-bold text-gray-400">Qualified</span>
              <div className="w-6 h-6 rounded-lg bg-emerald-500/15 flex items-center justify-center text-emerald-400">
                <CheckCircle2 className="w-3.5 h-3.5" />
              </div>
            </div>
            <div className="text-2xl font-black text-emerald-400 font-mono-digits">
              {qualifiedCount}
            </div>
            <span className="text-[10px] text-emerald-400/80 block mt-0.5">
              Unique IP + Completed
            </span>
          </div>

          {/* Card 4: Unqualified (Same IP) */}
          <div
            onClick={() => {
              setListToggle('my');
              setReferralFilter('SAME_IP');
              haptic.selection();
            }}
            className={`p-3.5 rounded-2xl bg-[#121824] border transition-all cursor-pointer hover:border-red-500/50 shadow-md ${
              listToggle === 'my' && referralFilter === 'SAME_IP'
                ? 'border-red-500 ring-1 ring-red-500/30 bg-red-950/10'
                : 'border-[#252D3D]'
            }`}
          >
            <div className="flex items-center justify-between mb-1">
              <span className="text-[11px] font-bold text-gray-400">Unqualified (Same IP)</span>
              <div className="w-6 h-6 rounded-lg bg-red-500/15 flex items-center justify-center text-red-400">
                <ShieldAlert className="w-3.5 h-3.5" />
              </div>
            </div>
            <div className="text-2xl font-black text-red-400 font-mono-digits">
              {sameIpCount}
            </div>
            <span className="text-[10px] text-red-400/80 block mt-0.5">
              Same IP / Device Match
            </span>
          </div>
        </div>
      </div>

      {/* 3. SQUAD MINING CARD (LIFETIME COMMISSION & CLAIM) */}
      <div className="relative overflow-hidden rounded-3xl bg-[#121824] border border-[#252D3D] p-5 shadow-xl">
        <div className="absolute top-0 right-0 w-32 h-32 bg-[#00E5FF]/10 rounded-full blur-2xl pointer-events-none" />

        <div className="flex items-center justify-between mb-2">
          <span className="text-[11px] font-extrabold uppercase tracking-wider text-gray-400">
            Squad Mining Pool
          </span>
          <span className="text-xs font-black text-[#00E5FF] px-2.5 py-0.5 rounded-full bg-[#00E5FF]/15 border border-[#00E5FF]/30 font-mono-digits">
            {config.referralCommissionPercent}% Dynamic Lifetime Commission
          </span>
        </div>

        <div className="my-2">
          <span className="text-xs text-gray-400 block">Unclaimed Squad Commission</span>
          <div className="flex items-baseline gap-2 mt-0.5">
            <span className="text-2xl font-black text-[#00E5FF] font-mono-digits">
              {user.unclaimedSquadPOP.toLocaleString(undefined, { minimumFractionDigits: 2, maximumFractionDigits: 2 })}
            </span>
            <span className="text-sm font-black text-white font-display">POP</span>
            <span className="text-xs text-gray-400 font-mono-digits">
              (≈ ${(user.unclaimedSquadPOP * config.popUsdRate).toFixed(2)} USD)
            </span>
          </div>
          <span className="text-[10px] text-gray-500 block mt-0.5">
            Total Claimed to Date: {user.claimedSquadPOP.toLocaleString()} POP
          </span>
        </div>

        {/* Claim Squad Commission Button */}
        <button
          onClick={handleClaimCommission}
          disabled={isClaiming || user.unclaimedSquadPOP <= 0}
          className={`w-full mt-3 py-3 rounded-2xl font-black text-xs tracking-wider uppercase transition-all flex items-center justify-center gap-2 font-display ${
            user.unclaimedSquadPOP > 0
              ? 'bg-[#00E5FF] hover:bg-[#00E5FF]/90 text-black shadow-lg shadow-cyan-500/20 active:scale-95 neon-glow-blue'
              : 'bg-[#1E2638] text-gray-500 border border-[#252D3D] cursor-not-allowed'
          }`}
        >
          {isClaiming ? (
            <div className="w-4 h-4 border-2 border-black border-t-transparent rounded-full animate-spin" />
          ) : (
            <>
              <Sparkles className="w-4 h-4" />
              <span>CLAIM SQUAD COMMISSION</span>
            </>
          )}
        </button>

        {claimSuccess && (
          <div className="mt-3 p-2.5 bg-emerald-500/20 border border-emerald-500/40 text-emerald-400 rounded-xl text-xs font-bold flex items-center gap-1.5">
            <CheckCircle2 className="w-4 h-4 shrink-0" />
            <span>{claimSuccess}</span>
          </div>
        )}
      </div>

      {/* 3. REFERRAL LINK & SHARE CONTROLS WITH RICH TELEGRAM PREVIEW */}
      <div className="p-4 rounded-3xl bg-[#121824] border border-[#252D3D] space-y-4 shadow-xl">
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-2">
            <Share2 className="w-4 h-4 text-[#00E5FF]" />
            <h4 className="text-xs font-black text-white font-display uppercase tracking-wide">
              Direct Mini App Referral Link
            </h4>
          </div>
          <span className="text-[10px] font-black text-[#FFE600] px-2 py-0.5 rounded-full bg-[#FFE600]/10 border border-[#FFE600]/30 font-mono-digits">
            +{config.instantReferralBonusPOP} POP / Qualified User
          </span>
        </div>

        {/* Clean Direct Link Input & One-Click Copy / Share Buttons */}
        <div className="space-y-2">
          <div className="flex items-center gap-2">
            <div className="flex-1 px-3.5 py-2.5 bg-[#0B0E14] border border-[#252D3D] rounded-2xl text-xs text-gray-200 font-mono-digits truncate select-all">
              {referralLink}
            </div>
            <button
              onClick={handleCopyLink}
              className={`py-2.5 px-3.5 rounded-2xl border text-xs font-extrabold flex items-center gap-1.5 transition-all active:scale-95 shrink-0 ${
                copiedLink
                  ? 'bg-emerald-500/20 border-emerald-500/50 text-emerald-400'
                  : 'bg-[#1A2234] border-[#252D3D] text-gray-200 hover:text-white hover:border-[#00E5FF]/40'
              }`}
              title="Copy Clean Direct Link"
            >
              {copiedLink ? (
                <>
                  <CheckCircle2 className="w-3.5 h-3.5 text-emerald-400" />
                  <span>Copied!</span>
                </>
              ) : (
                <>
                  <Copy className="w-3.5 h-3.5 text-gray-400" />
                  <span>Copy</span>
                </>
              )}
            </button>
          </div>

          {/* Primary "Invite Friends" / "Share Link" Button */}
          <button
            onClick={handleShareTelegram}
            className="w-full py-3 px-4 rounded-2xl bg-gradient-to-r from-[#00E5FF] via-[#00C2FF] to-[#FFE600] text-black font-black text-xs font-display uppercase tracking-wider flex items-center justify-center gap-2 shadow-lg shadow-[#00E5FF]/20 hover:brightness-110 active:scale-[0.98] transition-all"
          >
            <Send className="w-4 h-4" />
            <span>Invite Friends via Telegram</span>
          </button>
        </div>

        {/* INLINE BOT PREVIEW & METADATA HANDLING: Live Simulated Telegram Preview Card */}
        <div className="pt-2 border-t border-[#1E2638] space-y-2">
          <div className="flex items-center justify-between">
            <span className="text-[10px] font-bold uppercase tracking-wider text-gray-400 flex items-center gap-1">
              <Sparkles className="w-3 h-3 text-[#FFE600]" />
              Telegram Rich Chat Preview
            </span>
            <span className="text-[9px] text-[#00E5FF] font-semibold bg-[#00E5FF]/10 px-2 py-0.5 rounded-full border border-[#00E5FF]/20">
              Auto-Generated in Chat
            </span>
          </div>

          {/* Realistic Telegram Chat Card Preview */}
          <div className="p-3 rounded-2xl bg-[#1A2234]/80 border border-[#2A344A] text-left space-y-2.5">
            {/* Chat Text */}
            <p className="text-[11px] text-gray-200 font-sans leading-relaxed">
              🍿 Join PopCornUSA BOT & Start Mining POP Coins Now! Get instant welcome bonus! 🚀
            </p>

            {/* Telegram WebApp Inline Card */}
            <div className="rounded-xl overflow-hidden border border-[#2E3C56] bg-[#0E131F] shadow-md">
              {/* Photo Banner */}
              <div className="relative aspect-[16/9] w-full overflow-hidden bg-[#0A0D14]">
                <img
                  src="https://i.postimg.cc/8c4vM4H8/banner.jpg"
                  alt="PopCornUSA BOT Banner"
                  referrerPolicy="no-referrer"
                  className="w-full h-full object-cover"
                />
                <div className="absolute top-2 left-2 px-2 py-0.5 rounded-md bg-black/70 backdrop-blur-sm text-[9px] font-black text-[#FFE600] uppercase tracking-wider border border-white/10">
                  Mini App
                </div>
              </div>

              {/* Bot Title & Description */}
              <div className="p-2.5 space-y-1">
                <div className="flex items-center justify-between">
                  <h5 className="text-xs font-black text-white font-display">
                    PopCornUSA BOT
                  </h5>
                  <span className="text-[9px] text-gray-400">t.me/PopCornUSA_BOT</span>
                </div>
                <p className="text-[10px] text-gray-400 line-clamp-2">
                  Tap, mine, and invite friends to earn POP Coins on TON! Connect your TON wallet for instant payouts.
                </p>
              </div>

              {/* Telegram "LAUNCH" / "PLAY" Button Card */}
              <div className="p-2 bg-[#121824] border-t border-[#1F293D]">
                <button
                  onClick={handleShareTelegram}
                  className="w-full py-2 px-3 rounded-lg bg-[#24A1DE] hover:bg-[#1E8BC0] text-white font-black text-[11px] uppercase tracking-wider flex items-center justify-center gap-1.5 transition-all shadow-sm active:scale-95"
                >
                  <Play className="w-3.5 h-3.5 fill-current" />
                  <span>PLAY (Direct Mini App Launcher)</span>
                </button>
              </div>
            </div>

            <span className="text-[9px] text-gray-400 block text-center">
              Shared as direct Mini App link — Telegram auto-renders this rich photo banner and launcher card.
            </span>
          </div>
        </div>
      </div>

      {/* 4. MANDATORY ANTI-FRAUD & QUALIFICATION RULES EXPLANATION */}
      <div className="p-4 rounded-2xl bg-gradient-to-r from-[#161F30] to-[#121824] border border-[#00E5FF]/30 space-y-3 shadow-md">
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-2">
            <ShieldCheck className="w-4 h-4 text-[#00E5FF]" />
            <h4 className="text-xs font-black text-white font-display uppercase tracking-wide">
              Referral Qualification & Anti-Fraud Verification
            </h4>
          </div>
          <span className="text-[9px] bg-[#00E5FF]/15 text-[#00E5FF] border border-[#00E5FF]/30 px-2 py-0.5 rounded-full font-bold uppercase">
            3-Step Verification
          </span>
        </div>

        <p className="text-[11px] text-gray-300 leading-relaxed">
          When an invited friend joins using your link, they must satisfy all 3 criteria to unlock the <strong className="text-[#FFE600]">+{config.instantReferralBonusPOP} POP</strong> bonus and <strong className="text-[#00E5FF]">{config.referralCommissionPercent}%</strong> lifetime mining commission:
        </p>

        <div className="grid grid-cols-1 sm:grid-cols-3 gap-2 text-xs">
          <div className="p-2.5 rounded-xl bg-[#0B0E14] border border-[#1E2638] flex items-start gap-2">
            <span className="w-5 h-5 rounded-full bg-[#00E5FF]/20 text-[#00E5FF] flex items-center justify-center font-black text-[10px] shrink-0">
              1
            </span>
            <div>
              <span className="text-white font-bold block text-[11px]">Connect TON Wallet</span>
              <span className="text-[10px] text-gray-400">Verifies decentralized on-chain identity</span>
            </div>
          </div>

          <div className="p-2.5 rounded-xl bg-[#0B0E14] border border-[#1E2638] flex items-start gap-2">
            <span className="w-5 h-5 rounded-full bg-[#0088CC]/20 text-[#0088CC] flex items-center justify-center font-black text-[10px] shrink-0">
              2
            </span>
            <div>
              <span className="text-white font-bold block text-[11px]">Join Official TG Channel</span>
              <span className="text-[10px] text-gray-400">Subscribed to @PopCornUSA_BOT channel</span>
            </div>
          </div>

          <div className="p-2.5 rounded-xl bg-[#0B0E14] border border-[#1E2638] flex items-start gap-2">
            <span className="w-5 h-5 rounded-full bg-emerald-500/20 text-emerald-400 flex items-center justify-center font-black text-[10px] shrink-0">
              3
            </span>
            <div>
              <span className="text-white font-bold block text-[11px]">Different Device</span>
              <span className="text-[10px] text-gray-400">Separate physical hardware & IP address</span>
            </div>
          </div>
        </div>

        <div className="p-2.5 rounded-xl bg-amber-500/10 border border-amber-500/30 text-[10px] text-amber-200/90 flex items-start gap-2">
          <AlertTriangle className="w-3.5 h-3.5 text-amber-400 shrink-0 mt-0.5" />
          <span>
            <strong className="text-amber-300">Anti-Fraud Protection:</strong> Users joining on the same physical device or shared network will be listed as <strong className="text-amber-300">"UNQUALIFIED - SAME DEVICE"</strong>. Same-device referrals earn 0 POP bonus and 0% mining commissions.
          </span>
        </div>
      </div>

      {/* 5. WEEKLY CONTEST REWARD NOTICE CARD */}
      <div className="p-4 rounded-2xl bg-gradient-to-r from-[#161F30] to-[#121824] border border-[#FFE600]/30 shadow-md">
        <div className="flex items-center gap-2 mb-2">
          <Award className="w-4 h-4 text-[#FFE600]" />
          <h4 className="text-xs font-black text-white font-display uppercase tracking-wide">
            🏆 Weekly Referral Contest Rules
          </h4>
        </div>
        <p className="text-[11px] text-gray-300 leading-relaxed">
          Minimum <b className="text-[#FFE600] font-mono-digits">{config.weeklyContestMinThreshold} Qualified Referrals</b> in 7 days to qualify.
        </p>
        <div className="grid grid-cols-3 gap-1.5 mt-2.5 text-center text-[10px]">
          <div className="p-2 rounded-xl bg-[#0B0E14] border border-[#FFE600]/40">
            <span className="text-[#FFE600] block font-extrabold">👑 1st Place</span>
            <span className="text-white font-bold font-mono-digits">${config.weeklyPrizesUsdt.first.toFixed(2)} USDT</span>
          </div>
          <div className="p-2 rounded-xl bg-[#0B0E14] border border-gray-400/40">
            <span className="text-gray-300 block font-extrabold">🥈 2nd Place</span>
            <span className="text-white font-bold font-mono-digits">${config.weeklyPrizesUsdt.second.toFixed(2)} USDT</span>
          </div>
          <div className="p-2 rounded-xl bg-[#0B0E14] border border-amber-600/40">
            <span className="text-amber-500 block font-extrabold">🥉 3rd Place</span>
            <span className="text-white font-bold font-mono-digits">${config.weeklyPrizesUsdt.third.toFixed(2)} USDT</span>
          </div>
        </div>
        <div className="mt-2 text-[10px] text-gray-400 italic">
          *Qualification Rule: Referred user is QUALIFIED only after joining official channel, connecting TON wallet, and starting mining.
        </div>
      </div>

      {/* 6. DUAL LIST TOGGLE: [Top Referral List] (Default) & [My Referral List] */}
      <div className="grid grid-cols-2 p-1 bg-[#121824] border border-[#252D3D] rounded-2xl gap-1">
        <button
          onClick={() => {
            haptic.selection();
            setListToggle('top');
          }}
          className={`py-2 px-3 rounded-xl text-xs font-bold transition-all ${
            listToggle === 'top'
              ? 'bg-[#FFE600] text-black shadow-md font-display'
              : 'text-gray-400 hover:text-white'
          }`}
        >
          🏆 Top Referral List (Weekly)
        </button>
        <button
          onClick={() => {
            haptic.selection();
            setListToggle('my');
          }}
          className={`py-2 px-3 rounded-xl text-xs font-bold transition-all ${
            listToggle === 'my'
              ? 'bg-[#00E5FF] text-black shadow-md font-display'
              : 'text-gray-400 hover:text-white'
          }`}
        >
          👥 My Referral List ({referrals.length})
        </button>
      </div>

      {/* VIEW A: TOP 10 WEEKLY REFERRAL LEADERBOARD */}
      {listToggle === 'top' && (
        <div className="space-y-3">
          
          {/* Top 3 Podium Cards: 2nd (Left Silver), 1st (Center Golden Crown 👑), 3rd (Right Bronze) */}
          <div className="grid grid-cols-3 gap-2 items-end pt-3">
            
            {/* 2nd Place (Left Silver) */}
            <div className="p-3 rounded-2xl bg-[#121824] border border-gray-400/30 text-center flex flex-col items-center shadow-lg">
              <span className="text-xs font-extrabold text-gray-300">🥈 2nd</span>
              <div className="w-10 h-10 rounded-full bg-[#1A2234] border border-gray-400/50 my-1.5 flex items-center justify-center font-bold text-xs text-white">
                {rank2?.username?.slice(0, 2).toUpperCase() || '2N'}
              </div>
              <span className="text-xs font-bold text-white truncate max-w-full">
                @{rank2?.username || 'user'}
              </span>
              <span className="text-[11px] font-black text-[#FFE600] font-mono-digits mt-1">
                {rank2?.referralCount || 0} refs
              </span>
              <span className="text-[9px] text-gray-400 font-mono-digits">
                {rank2?.totalPopEarnings || 0} POP
              </span>
            </div>

            {/* 1st Place (Center Golden Crown 👑) */}
            <div className="p-3.5 rounded-2xl bg-gradient-to-b from-[#1E2638] to-[#121824] border-2 border-[#FFE600] text-center flex flex-col items-center shadow-xl shadow-yellow-500/10 scale-105 z-10">
              <div className="flex items-center gap-1 text-[#FFE600]">
                <Crown className="w-4 h-4 fill-[#FFE600]" />
                <span className="text-xs font-black uppercase font-display">1st Winner</span>
              </div>
              <div className="w-12 h-12 rounded-full bg-[#FFE600]/20 border-2 border-[#FFE600] my-1.5 flex items-center justify-center font-black text-sm text-[#FFE600]">
                {rank1?.username?.slice(0, 2).toUpperCase() || '1S'}
              </div>
              <span className="text-xs font-black text-white truncate max-w-full">
                @{rank1?.username || 'user'}
              </span>
              <span className="text-xs font-black text-[#FFE600] font-mono-digits mt-1">
                {rank1?.referralCount || 0} refs
              </span>
              <span className="text-[10px] text-emerald-400 font-mono-digits font-bold">
                {rank1?.totalPopEarnings || 0} POP
              </span>
            </div>

            {/* 3rd Place (Right Bronze) */}
            <div className="p-3 rounded-2xl bg-[#121824] border border-amber-600/30 text-center flex flex-col items-center shadow-lg">
              <span className="text-xs font-extrabold text-amber-500">🥉 3rd</span>
              <div className="w-10 h-10 rounded-full bg-[#1A2234] border border-amber-600/50 my-1.5 flex items-center justify-center font-bold text-xs text-white">
                {rank3?.username?.slice(0, 2).toUpperCase() || '3R'}
              </div>
              <span className="text-xs font-bold text-white truncate max-w-full">
                @{rank3?.username || 'user'}
              </span>
              <span className="text-[11px] font-black text-[#FFE600] font-mono-digits mt-1">
                {rank3?.referralCount || 0} refs
              </span>
              <span className="text-[9px] text-gray-400 font-mono-digits">
                {rank3?.totalPopEarnings || 0} POP
              </span>
            </div>
          </div>

          {/* Ranks 4 to 10 Ranked List */}
          <div className="space-y-1.5 mt-2">
            <span className="text-[10px] font-bold text-gray-400 uppercase px-1">Ranks 4 to 10</span>
            {ranksRest.length === 0 ? (
              <div className="p-4 bg-[#0B0E14] rounded-2xl text-center text-xs text-gray-500 border border-[#1E2638]">
                No other qualified inviters in this 7-day cycle yet.
              </div>
            ) : (
              ranksRest.map((entry) => (
                <div
                  key={entry.rank}
                  className={`p-3 rounded-xl border flex items-center justify-between transition-colors ${
                    entry.isCurrentUser
                      ? 'bg-[#00E5FF]/10 border-[#00E5FF]/50 text-white'
                      : 'bg-[#121824] border-[#1E2638] text-gray-300'
                  }`}
                >
                  <div className="flex items-center gap-3">
                    <span className="w-5 font-mono-digits text-xs font-bold text-gray-400">
                      #{entry.rank}
                    </span>
                    <div>
                      <span className="text-xs font-bold text-white block">@{entry.username}</span>
                      <span className="text-[10px] text-gray-400 font-mono-digits">
                        Earnings: {entry.totalPopEarnings} POP
                      </span>
                    </div>
                  </div>

                  <div className="text-right">
                    <span className="text-xs font-black text-[#FFE600] font-mono-digits block">
                      {entry.referralCount} refs
                    </span>
                    {entry.referralCount >= config.weeklyContestMinThreshold && (
                      <span className="text-[9px] text-emerald-400 font-semibold">Eligible</span>
                    )}
                  </div>
                </div>
              ))
            )}
          </div>
        </div>
      )}

      {/* VIEW B: MY REFERRAL LIST */}
      {listToggle === 'my' && (
        <div className="space-y-3">
          {/* Referral List Filter Bar */}
          {referrals.length > 0 && (
            <div className="flex items-center gap-1.5 overflow-x-auto pb-1 text-xs no-scrollbar">
              <button
                onClick={() => {
                  haptic.selection();
                  setReferralFilter('ALL');
                }}
                className={`px-3 py-1.5 rounded-xl font-bold whitespace-nowrap transition-all ${
                  referralFilter === 'ALL'
                    ? 'bg-[#00E5FF] text-black shadow-md'
                    : 'bg-[#121824] border border-[#252D3D] text-gray-400 hover:text-white'
                }`}
              >
                All ({totalJoined})
              </button>
              <button
                onClick={() => {
                  haptic.selection();
                  setReferralFilter('PENDING');
                }}
                className={`px-3 py-1.5 rounded-xl font-bold whitespace-nowrap transition-all ${
                  referralFilter === 'PENDING'
                    ? 'bg-amber-400 text-black shadow-md'
                    : 'bg-[#121824] border border-[#252D3D] text-gray-400 hover:text-white'
                }`}
              >
                Pending Action ({pendingCount})
              </button>
              <button
                onClick={() => {
                  haptic.selection();
                  setReferralFilter('QUALIFIED');
                }}
                className={`px-3 py-1.5 rounded-xl font-bold whitespace-nowrap transition-all ${
                  referralFilter === 'QUALIFIED'
                    ? 'bg-emerald-500 text-black shadow-md'
                    : 'bg-[#121824] border border-[#252D3D] text-gray-400 hover:text-white'
                }`}
              >
                Qualified ({qualifiedCount})
              </button>
              <button
                onClick={() => {
                  haptic.selection();
                  setReferralFilter('SAME_IP');
                }}
                className={`px-3 py-1.5 rounded-xl font-bold whitespace-nowrap transition-all ${
                  referralFilter === 'SAME_IP'
                    ? 'bg-red-500 text-white shadow-md'
                    : 'bg-[#121824] border border-[#252D3D] text-gray-400 hover:text-white'
                }`}
              >
                Unqualified (Same IP) ({sameIpCount})
              </button>
            </div>
          )}

          {referrals.length === 0 ? (
            <div className="p-8 rounded-2xl bg-[#121824] border border-[#252D3D] text-center space-y-2">
              <Users2 className="w-8 h-8 text-gray-500 mx-auto" />
              <h4 className="text-xs font-bold text-white">No referrals yet</h4>
              <p className="text-[11px] text-gray-400 max-w-xs mx-auto">
                Share your invite link with friends! When they connect their TON wallet & join our channel on a separate device, you instantly earn +{config.instantReferralBonusPOP} POP and {config.referralCommissionPercent}% mining commission.
              </p>
              <button
                onClick={handleShareTelegram}
                className="mt-3 py-2.5 px-5 bg-gradient-to-r from-[#00E5FF] to-[#FFE600] text-black font-extrabold text-xs rounded-xl font-display uppercase tracking-wider flex items-center justify-center gap-2 mx-auto shadow-lg hover:brightness-110 active:scale-95 transition-all"
              >
                <Send className="w-3.5 h-3.5" />
                <span>Invite Friends via Telegram</span>
              </button>
            </div>
          ) : (
            referrals
              .filter((ref) => {
                const isSameIp = ref.status === 'Unqualified (Same IP / Device Match)' ||
                                 ref.status === 'UNQUALIFIED - SAME IP' || 
                                 ref.status === 'UNQUALIFIED - SAME DEVICE' || 
                                 ref.status === 'Unqualified' ||
                                 (ref.hasWallet && ref.hasChannel && ref.isMultiAccount);
                const isQual = !isSameIp && (
                  ref.status === 'Qualified' ||
                  ref.status === 'QUALIFIED' ||
                  (ref.isQualified && ref.hasWallet && ref.hasChannel)
                );
                const isPending = !isSameIp && !isQual;

                if (referralFilter === 'QUALIFIED') return isQual;
                if (referralFilter === 'SAME_IP') return isSameIp;
                if (referralFilter === 'PENDING') return isPending;
                return true;
              })
              .map((ref) => {
                const isSameIp = ref.status === 'Unqualified (Same IP / Device Match)' ||
                                 ref.status === 'UNQUALIFIED - SAME IP' || 
                                 ref.status === 'UNQUALIFIED - SAME DEVICE' || 
                                 ref.status === 'Unqualified' ||
                                 (ref.hasWallet && ref.hasChannel && ref.isMultiAccount);
                const isQualified = !isSameIp && (
                  ref.status === 'Qualified' ||
                  ref.status === 'QUALIFIED' ||
                  (ref.isQualified && ref.hasWallet && ref.hasChannel)
                );
                const isPending = !isQualified && !isSameIp;

                const pendingRequirements: string[] = [];
                if (!ref.hasWallet) pendingRequirements.push('Connect TON Wallet');
                if (!ref.hasChannel) pendingRequirements.push('Join Official Channel');

                const displayName = ref.username
                  ? `@${ref.username}`
                  : (ref.first_name || ref.firstName || `user_${ref.telegramId}`);

                return (
                  <div
                    key={ref.id}
                    className={`p-4 rounded-2xl border transition-all ${
                      isSameIp
                        ? 'bg-red-950/20 border-red-500/40 shadow-sm shadow-red-950/20'
                        : isQualified
                        ? 'bg-[#121824] border-emerald-500/40 shadow-sm shadow-emerald-500/5'
                        : 'bg-[#121824] border-amber-500/30'
                    }`}
                  >
                    <div className="flex items-start justify-between gap-2.5">
                      <div className="flex-1 min-w-0">
                        {/* Username & Exact Status Badge */}
                        <div className="flex items-center gap-2 flex-wrap mb-1">
                          <span className="text-xs font-black text-white truncate">
                            {displayName}
                          </span>
                          <span className="text-[10px] text-gray-400 font-mono-digits">
                            (ID: {ref.telegramId})
                          </span>

                          {/* 1. 🟢 QUALIFIED: Unique IP + Wallet + Channel completed */}
                          {isQualified && (
                            <span className="text-[9px] bg-emerald-500/20 text-emerald-400 border border-emerald-500/40 px-2.5 py-0.5 rounded-full font-black uppercase tracking-wider flex items-center gap-1 font-display">
                              <span className="w-1.5 h-1.5 rounded-full bg-emerald-400 animate-pulse" />
                              <span>Qualified</span>
                            </span>
                          )}

                          {/* 2. 🟡 PENDING: Joined via link, requirements missing */}
                          {isPending && (
                            <span className="text-[9px] bg-amber-500/20 text-amber-300 border border-amber-500/40 px-2.5 py-0.5 rounded-full font-black tracking-wider flex items-center gap-1 font-display">
                              <Clock className="w-2.5 h-2.5 shrink-0 text-amber-400" />
                              <span>PENDING (Missing Wallet / Channel)</span>
                            </span>
                          )}

                          {/* 3. 🔴 UNQUALIFIED: Detected on same IP/Device */}
                          {isSameIp && (
                            <span className="text-[9px] bg-red-500/20 text-red-300 border border-red-500/40 px-2.5 py-0.5 rounded-full font-black tracking-wider flex items-center gap-1 font-display">
                              <ShieldAlert className="w-2.5 h-2.5 shrink-0 text-red-400" />
                              <span>Unqualified (Same IP / Device Match)</span>
                            </span>
                          )}
                        </div>

                        {/* Total Bonus Earned Display */}
                        <div className="flex items-center gap-3 mt-1.5 text-[11px] flex-wrap">
                          <div className="flex items-baseline gap-1">
                            <span className="text-gray-400">Bonus Earned:</span>
                            {isQualified ? (
                              <span className="text-emerald-400 font-black font-mono-digits">
                                +{ref.bonusAwardedPOP || 100} POP
                              </span>
                            ) : isSameIp ? (
                              <span className="text-red-400 font-bold font-mono-digits">
                                $0 bonus (0 POP)
                              </span>
                            ) : (
                              <span className="text-amber-300 font-bold font-mono-digits">
                                Pending (+100 POP)
                              </span>
                            )}
                          </div>

                          <span className="text-gray-600">•</span>

                          <div className="flex items-baseline gap-1">
                            <span className="text-gray-400">Mining Commission:</span>
                            {isQualified ? (
                              <span className="text-[#00E5FF] font-bold font-mono-digits">
                                {config.referralCommissionPercent}% Active
                              </span>
                            ) : (
                              <span className="text-gray-500 font-semibold">
                                0% (Inactive)
                              </span>
                            )}
                          </div>
                        </div>

                        {/* Status detail notes */}
                        {isSameIp && (
                          <div className="mt-2 p-2 rounded-xl bg-red-950/40 border border-red-500/30 text-[10px] text-red-300 flex items-start gap-1.5">
                            <AlertTriangle className="w-3.5 h-3.5 text-red-400 shrink-0 mt-0.5" />
                            <span>
                              Detected on same IP / Hotspot / Device. Referral bonus ($0) and mining commissions forfeited.
                            </span>
                          </div>
                        )}

                        {isPending && (
                          <p className="text-[10px] text-amber-300/90 mt-1.5 flex items-center gap-1.5">
                            <Clock className="w-3 h-3 text-amber-400 shrink-0" />
                            <span>Joined via invite link. Waiting for referee to complete: <strong className="text-white">{pendingRequirements.join(' + ') || 'Wallet / Channel'}</strong>.</span>
                          </p>
                        )}
                      </div>

                      {/* 3 Qualification Verification Checkpoints */}
                      <div className="flex flex-col items-end gap-1 shrink-0 pt-0.5">
                        <span
                          title={ref.hasWallet ? 'TON Wallet Connected' : 'TON Wallet Pending'}
                          className={`px-2 py-0.5 rounded-lg text-[9px] font-mono-digits flex items-center gap-1 ${
                            ref.hasWallet
                              ? 'bg-emerald-500/15 text-emerald-400 border border-emerald-500/30 font-bold'
                              : 'bg-gray-800/80 text-gray-400 border border-gray-700'
                          }`}
                        >
                          <span className={`w-1.5 h-1.5 rounded-full ${ref.hasWallet ? 'bg-emerald-400' : 'bg-gray-500'}`} />
                          TON Wallet
                        </span>

                        <span
                          title={ref.hasChannel ? 'TG Channel Joined' : 'TG Channel Pending'}
                          className={`px-2 py-0.5 rounded-lg text-[9px] font-mono-digits flex items-center gap-1 ${
                            ref.hasChannel
                              ? 'bg-emerald-500/15 text-emerald-400 border border-emerald-500/30 font-bold'
                              : 'bg-gray-800/80 text-gray-400 border border-gray-700'
                          }`}
                        >
                          <span className={`w-1.5 h-1.5 rounded-full ${ref.hasChannel ? 'bg-emerald-400' : 'bg-gray-500'}`} />
                          TG Channel
                        </span>

                        <span
                          title={!isSameIp ? 'Unique Device Hardware / IP' : 'Same IP / Device Match'}
                          className={`px-2 py-0.5 rounded-lg text-[9px] font-mono-digits flex items-center gap-1 ${
                            !isSameIp
                              ? 'bg-emerald-500/15 text-emerald-400 border border-emerald-500/30 font-bold'
                              : 'bg-red-500/15 text-red-400 border border-red-500/30 font-bold'
                          }`}
                        >
                          <span className={`w-1.5 h-1.5 rounded-full ${!isSameIp ? 'bg-emerald-400' : 'bg-red-500'}`} />
                          {!isSameIp ? 'Unique IP' : 'Same IP'}
                        </span>
                      </div>
                    </div>
                  </div>
                );
              })
          )}
        </div>
      )}
    </div>
  );
};
