import { connectMongo, isMongoConnected, getMongoStatusDetails, activeMongoUri } from './mongoose.js';
import { UserModel, ReferralLogModel, SystemSettingsModel, IUserDocument, IReferralLogDocument } from './models/index.js';
import { User, ReferralUserItem, AdminConfig } from '../src/types.js';

let lastMongoError: string | null = null;

// Initial non-blocking connection attempt
connectMongo().catch(() => {});

export function getMongoStatus() {
  const details = getMongoStatusDetails();
  return {
    ...details,
    connected: details.isConnected,
    error: details.error || lastMongoError,
  };
}

/**
 * Maps an internal User object to MongoDB User Document fields
 */
export function mapUserToMongoFields(user: User, isAdmin: boolean = false) {
  return {
    telegram_id: String(user.telegramId),
    username: user.username || '',
    first_name: user.firstName || '',
    points: Math.max(0, Math.floor(user.balancePOP || 0)),
    last_mined_at: user.lastClaimedAt ? new Date(user.lastClaimedAt) : new Date(),
    wallet_address: user.tonWalletAddress || null,
    joined_channel: Boolean(user.hasJoinedChannel),
    referred_by: user.referrerId ? String(user.referrerId).replace(/^usr-/, '').replace(/^ref[_-]/i, '') : null,
    ip_address: user.ipAddress || null,
    device_id: user.deviceFingerprint || null,
    is_admin: isAdmin,
    miner_level: user.minerLevel || 1,
    storage_tier: user.storageTier || 1,
    mining_started_at: user.miningStartedAt ? new Date(user.miningStartedAt) : new Date(),
    daily_streak: user.dailyStreak || 0,
    last_checkin_date: user.lastCheckInDate || null,
    unclaimed_squad_pop: user.unclaimedSquadPOP || 0,
    claimed_squad_pop: user.claimedSquadPOP || 0,
    completed_tasks: user.completedTasks || [],
    is_flagged: Boolean(user.isFlagged),
    flagged_reason: user.flaggedReason || null,
  };
}

/**
 * Maps a MongoDB User document back to the in-app User model
 */
export function mapMongoDocToUser(doc: any): User {
  return {
    id: `usr-${doc.telegram_id}`,
    telegramId: String(doc.telegram_id),
    username: doc.username || `user_${String(doc.telegram_id).slice(-4)}`,
    firstName: doc.first_name || 'POP Miner',
    lastName: '',
    photoUrl: '',
    tonWalletAddress: doc.wallet_address || null,
    balancePOP: doc.points ?? 0,
    unclaimedMiningPOP: 0,
    minerLevel: doc.miner_level || 1,
    storageTier: doc.storage_tier || 1,
    miningStartedAt: doc.mining_started_at ? new Date(doc.mining_started_at).toISOString() : new Date().toISOString(),
    lastClaimedAt: doc.last_mined_at ? new Date(doc.last_mined_at).toISOString() : new Date().toISOString(),
    referrerId: doc.referred_by || null,
    isQualified: false, // Calculated from referral log
    hasJoinedChannel: Boolean(doc.joined_channel),
    hasStartedMining: true,
    ipAddress: doc.ip_address || '127.0.0.1',
    deviceFingerprint: doc.device_id || `dfp_${doc.telegram_id}`,
    isFlagged: Boolean(doc.is_flagged),
    flaggedReason: doc.flagged_reason || undefined,
    dailyStreak: doc.daily_streak || 0,
    lastCheckInDate: doc.last_checkin_date || null,
    totalMined: doc.points ?? 0,
    squadCommissionRate: 10,
    unclaimedSquadPOP: doc.unclaimed_squad_pop || 0,
    claimedSquadPOP: doc.claimed_squad_pop || 0,
    completedTasks: doc.completed_tasks || [],
    createdAt: doc.created_at ? new Date(doc.created_at).toISOString() : new Date().toISOString(),
  };
}

/**
 * Persists or updates a User in MongoDB Atlas
 */
export async function syncUserToMongo(user: User, isAdmin: boolean = false): Promise<void> {
  if (!isMongoConnected()) return;
  try {
    const fields = mapUserToMongoFields(user, isAdmin);
    await UserModel.findOneAndUpdate(
      { telegram_id: fields.telegram_id },
      { $set: fields },
      { upsert: true, new: true, setDefaultsOnInsert: true }
    );
  } catch (err: any) {
    lastMongoError = err?.message || String(err);
    console.warn('[MongoDB Atlas] syncUserToMongo error:', err?.message);
  }
}

/**
 * Creates or retrieves a Referral Log in MongoDB with initial status: "Pending"
 */
export async function logReferralInMongo(params: {
  referrerTelegramId: string;
  referredTelegramId: string;
  referredUsername?: string;
  referredFirstName?: string;
  inviterIp?: string;
  inviterDevice?: string;
  referredIp?: string;
  referredDevice?: string;
}): Promise<IReferralLogDocument | null> {
  if (!isMongoConnected()) return null;
  try {
    const existing = await ReferralLogModel.findOne({
      referrer_id: params.referrerTelegramId,
      referred_id: params.referredTelegramId,
    });

    if (existing) {
      return existing;
    }

    const newLog = new ReferralLogModel({
      referrer_id: params.referrerTelegramId,
      referred_id: params.referredTelegramId,
      status: 'Pending',
      reason: null,
      bonus_awarded: 0,
      referred_username: params.referredUsername || '',
      referred_first_name: params.referredFirstName || '',
      has_wallet: false,
      has_channel: false,
      inviter_ip: params.inviterIp || null,
      inviter_device: params.inviterDevice || null,
      referred_ip: params.referredIp || null,
      referred_device: params.referredDevice || null,
    });

    await newLog.save();
    console.log(`[MongoDB Atlas] Logged referral: ${params.referredTelegramId} -> ${params.referrerTelegramId} [STATUS: Pending]`);
    return newLog;
  } catch (err: any) {
    lastMongoError = err?.message || String(err);
    console.warn('[MongoDB Atlas] logReferralInMongo error:', err?.message);
    return null;
  }
}

/**
 * Verifies referral qualification when user completes wallet & channel requirements
 */
export async function verifyAndQualifyReferralInMongo(params: {
  referredTelegramId: string;
  hasWallet: boolean;
  hasChannel: boolean;
  bonusAmount: number;
}): Promise<{
  success: boolean;
  status: 'Pending' | 'Qualified' | 'Unqualified';
  reason?: string;
  awardedBonus: number;
  referrerTelegramId?: string;
}> {
  if (!isMongoConnected()) {
    return { success: false, status: 'Pending', awardedBonus: 0 };
  }

  try {
    const log = await ReferralLogModel.findOne({ referred_id: params.referredTelegramId });
    if (!log) {
      return { success: false, status: 'Pending', awardedBonus: 0 };
    }

    // Update requirements state
    log.has_wallet = params.hasWallet;
    log.has_channel = params.hasChannel;

    // Check if requirements are met
    if (!params.hasWallet || !params.hasChannel) {
      log.status = 'Pending';
      await log.save();
      return {
        success: true,
        status: 'Pending',
        reason: 'Waiting for TON Wallet and Channel Join',
        awardedBonus: 0,
        referrerTelegramId: log.referrer_id,
      };
    }

    // FRAUD CHECK: Compare IP Address and Device ID
    const sameIp =
      log.inviter_ip &&
      log.referred_ip &&
      log.inviter_ip === log.referred_ip &&
      log.inviter_ip !== '127.0.0.1' &&
      !log.inviter_ip.includes('::1');

    const sameDevice =
      log.inviter_device &&
      log.referred_device &&
      log.inviter_device === log.referred_device;

    const isFraud = sameIp || sameDevice || log.referrer_id === log.referred_id;

    if (isFraud) {
      log.status = 'Unqualified';
      log.reason = sameIp && sameDevice
        ? 'Same IP and Device ID detected'
        : sameIp
        ? 'Same IP address detected'
        : 'Same Device ID detected';
      await log.save();

      console.log(`[MongoDB Atlas] Referral ${log.referred_id} marked UNQUALIFIED: ${log.reason}`);
      return {
        success: true,
        status: 'Unqualified',
        reason: log.reason,
        awardedBonus: 0,
        referrerTelegramId: log.referrer_id,
      };
    }

    // If already qualified, do not double-reward
    if (log.status === 'Qualified') {
      return {
        success: true,
        status: 'Qualified',
        awardedBonus: log.bonus_awarded || 0,
        referrerTelegramId: log.referrer_id,
      };
    }

    // Unique IP and Device ID -> QUALIFIED!
    log.status = 'Qualified';
    log.reason = 'Requirements completed on unique device & IP';
    log.bonus_awarded = params.bonusAmount;
    await log.save();

    // Award bonus points to the inviter in MongoDB Atlas
    const inviterDoc = await UserModel.findOneAndUpdate(
      { telegram_id: log.referrer_id },
      { $inc: { points: params.bonusAmount } },
      { new: true }
    );

    console.log(`[MongoDB Atlas] Referral ${log.referred_id} QUALIFIED! Awarded +${params.bonusAmount} points to inviter ${log.referrer_id}. New points: ${inviterDoc?.points}`);

    return {
      success: true,
      status: 'Qualified',
      awardedBonus: params.bonusAmount,
      referrerTelegramId: log.referrer_id,
    };
  } catch (err: any) {
    lastMongoError = err?.message || String(err);
    console.warn('[MongoDB Atlas] verifyAndQualifyReferralInMongo error:', err?.message);
    return { success: false, status: 'Pending', awardedBonus: 0 };
  }
}

/**
 * Adjusts user points directly in MongoDB Atlas (Admin Action)
 */
export async function adjustUserPointsInMongo(
  telegramId: string,
  amount: number,
  mode: 'add' | 'deduct' | 'set'
): Promise<{ success: boolean; newPoints: number; user?: any }> {
  if (!isMongoConnected()) {
    return { success: false, newPoints: 0 };
  }

  try {
    let updateQuery: any = {};
    if (mode === 'add') {
      updateQuery = { $inc: { points: Math.abs(amount) } };
    } else if (mode === 'deduct') {
      updateQuery = { $inc: { points: -Math.abs(amount) } };
    } else {
      updateQuery = { $set: { points: Math.max(0, amount) } };
    }

    const updated = await UserModel.findOneAndUpdate(
      { telegram_id: String(telegramId) },
      updateQuery,
      { new: true }
    );

    if (updated && updated.points < 0) {
      updated.points = 0;
      await updated.save();
    }

    console.log(`[MongoDB Atlas] Admin adjusted points for ${telegramId} (${mode} ${amount}) -> New Points: ${updated?.points}`);
    return { success: Boolean(updated), newPoints: updated?.points ?? 0, user: updated };
  } catch (err: any) {
    lastMongoError = err?.message || String(err);
    console.warn('[MongoDB Atlas] adjustUserPointsInMongo error:', err?.message);
    return { success: false, newPoints: 0 };
  }
}

/**
 * Saves System Settings / Admin Config directly to MongoDB Atlas
 */
export async function saveSystemSettingsToMongo(config: AdminConfig): Promise<void> {
  if (!isMongoConnected()) return;
  try {
    await SystemSettingsModel.findOneAndUpdate(
      { key: 'admin_config' },
      {
        $set: {
          key: 'admin_config',
          mandatory_telegram_channel: config.mandatoryTelegramChannel || '@PopCornUSA_BOT',
          mandatory_channel_link: config.mandatoryChannelLink || 'https://t.me/PopCornUSA_BOT',
          channel_url: config.channelUrl || 'https://t.me/buliya213',
          instant_referral_bonus_pop: config.instantReferralBonusPOP ?? 25,
          referral_commission_percent: config.referralCommissionPercent ?? 10,
          pop_usd_rate: config.popUsdRate ?? 0.001,
          anti_cheat_enabled: config.antiCheatEnabled ?? true,
          miner_tiers: config.minerTiers || [],
          storage_tiers: config.storageTiers || [],
          weekly_contest_min_threshold: config.weeklyContestMinThreshold ?? 40,
          weekly_prizes_usdt: config.weeklyPrizesUsdt || { first: 1.0, second: 0.6, third: 0.3 },
          support_username: config.telegramSupportUsername || '@PopCornUSA_BOT',
          welcome_banner_url: config.welcomeBannerUrl || 'https://i.postimg.cc/8c4vM4H8/banner.jpg',
          raw_config: config,
          updated_at: new Date(),
        },
      },
      { upsert: true, new: true }
    );
    console.log('[MongoDB Atlas] Successfully saved system settings & admin config.');
  } catch (err: any) {
    lastMongoError = err?.message || String(err);
    console.warn('[MongoDB Atlas] saveSystemSettingsToMongo error:', err?.message);
  }
}

/**
 * Loads System Settings from MongoDB Atlas on startup
 */
export async function loadSystemSettingsFromMongo(): Promise<Partial<AdminConfig> | null> {
  if (!isMongoConnected()) return null;
  try {
    const doc = await SystemSettingsModel.findOne({ key: 'admin_config' });
    if (!doc) return null;

    return {
      mandatoryTelegramChannel: doc.mandatory_telegram_channel,
      mandatoryChannelLink: doc.mandatory_channel_link,
      channelUrl: doc.channel_url,
      instantReferralBonusPOP: doc.instant_referral_bonus_pop,
      referralCommissionPercent: doc.referral_commission_percent,
      popUsdRate: doc.pop_usd_rate,
      antiCheatEnabled: doc.anti_cheat_enabled,
      minerTiers: doc.miner_tiers?.length ? doc.miner_tiers : undefined,
      storageTiers: doc.storage_tiers?.length ? doc.storage_tiers : undefined,
      weeklyContestMinThreshold: doc.weekly_contest_min_threshold,
      weeklyPrizesUsdt: doc.weekly_prizes_usdt,
      telegramSupportUsername: doc.support_username,
      welcomeBannerUrl: doc.welcome_banner_url,
      ...(doc.raw_config || {}),
    };
  } catch (err: any) {
    lastMongoError = err?.message || String(err);
    console.warn('[MongoDB Atlas] loadSystemSettingsFromMongo error:', err?.message);
    return null;
  }
}

/**
 * Retrieves all referral logs for a given referrer
 */
export async function getReferralLogsForReferrer(referrerTelegramId: string): Promise<IReferralLogDocument[]> {
  if (!isMongoConnected()) return [];
  try {
    return await ReferralLogModel.find({ referrer_id: String(referrerTelegramId) }).sort({ created_at: -1 });
  } catch (err: any) {
    console.warn('[MongoDB Atlas] getReferralLogsForReferrer error:', err?.message);
    return [];
  }
}

/**
 * Calculates and returns real-time squad statistics and formatted referrals from MongoDB
 */
export async function getMongoSquadStats(referrerTelegramId: string): Promise<{
  counts: { total: number; pending: number; qualified: number; same_ip: number };
  referrals: any[];
} | null> {
  if (!isMongoConnected()) return null;
  try {
    const logs = await ReferralLogModel.find({
      $or: [{ referrer_id: String(referrerTelegramId) }]
    }).sort({ created_at: -1 }).lean();

    let total = logs.length;
    let qualified = 0;
    let pending = 0;
    let same_ip = 0;

    const formattedList = logs.map((log: any) => {
      const isQual = log.status === 'Qualified' || log.status === 'QUALIFIED';
      const isUnqual =
        log.status === 'Unqualified' ||
        log.status === 'UNQUALIFIED - SAME IP' ||
        log.status === 'Unqualified (Same IP / Device Match)';

      let statusDisplay = 'PENDING (Missing Wallet / Channel)';
      if (isQual) {
        statusDisplay = 'Qualified';
        qualified++;
      } else if (isUnqual) {
        statusDisplay = 'Unqualified (Same IP / Device Match)';
        same_ip++;
      } else {
        pending++;
      }

      return {
        telegram_id: String(log.referred_id),
        username: log.referred_username || `user_${String(log.referred_id).slice(-4)}`,
        first_name: log.referred_first_name || log.referred_username || 'POP Miner',
        status: statusDisplay,
        created_at: log.created_at ? new Date(log.created_at).toISOString() : new Date().toISOString(),
        id: `usr-${log.referred_id}`,
        telegramId: String(log.referred_id),
        isQualified: isQual,
        hasWallet: Boolean(log.has_wallet),
        hasChannel: Boolean(log.has_channel),
        hasMined: true,
        isMultiAccount: isUnqual,
        bonusAwardedPOP: log.bonus_awarded || (isQual ? 100 : 0),
        joinedAt: log.created_at ? new Date(log.created_at).toISOString() : new Date().toISOString(),
      };
    });

    return {
      counts: { total, pending, qualified, same_ip },
      referrals: formattedList,
    };
  } catch (err: any) {
    console.warn('[MongoDB Atlas] getMongoSquadStats error:', err?.message);
    return null;
  }
}

